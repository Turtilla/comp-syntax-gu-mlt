TreeForm for InfoVis reviewers:


This is version 0.9.3, and was used in the second round of cognitive walkthroughs.

Version 0.8.2 was used in the first round of cognitive walkthroughs.  It can be found at http://sourceforge.net/projects/treeform

To start TreeForm in Mac:

run the TreeForm.app program

To start TreeForm in Windows:

run the TreeForm.bat file

To start TreeForm in another system:

java -Xmx256m -Xms64m -jar TreeForm.jar 

TreeForm works best if you have the DOULOS SIL font installed from:

http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&item_id=DoulosSIL_download#dc835487

TreeForm will still look good with default fonts, but not as I intended.

Donald Derrick
Daniel Archambault
