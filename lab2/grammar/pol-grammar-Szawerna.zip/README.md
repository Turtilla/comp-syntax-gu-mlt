## TO READ BEFORE GRADING
In this course I first wanted to do the Micro + Doctor project option, but upon discovering that the Doctor application would not work with my MicroGrammar, I decided to
do the Mini Grammar instead. However, I still wanted to try to do the Doctor Application, so I am submitting it as well - although if I have to choose, I want to be graded
on the basis of my Mini Grammar, and the Doctor application is there just as an extra.
